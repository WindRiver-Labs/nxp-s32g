/*
 * Copyright (C) 2018 Marvell International Ltd.
 *
 * SPDX-License-Identifier:     BSD-3-Clause
 * https://spdx.org/licenses
 */

#define DRAM_MAX_IFACE			1
#define DRAM_CH0_MMAP_LOW_OFFSET	0x20200
