/*
 * Copyright (C) 2018 Marvell International Ltd.
 *
 * SPDX-License-Identifier:     BSD-3-Clause
 * https://spdx.org/licenses
 */

#ifndef DDR_INFO_H
#define DDR_INFO_H

#define DRAM_MAX_IFACE			1
#define DRAM_CH0_MMAP_LOW_OFFSET	0x200

#endif /* DDR_INFO_H */
