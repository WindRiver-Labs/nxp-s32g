/*
 * Copyright (C) 2018 Marvell International Ltd.
 *
 * SPDX-License-Identifier:     BSD-3-Clause
 * https://spdx.org/licenses
 */

#ifndef MVEBU_DEF_H
#define MVEBU_DEF_H

#include <a3700_plat_def.h>

#endif /* MVEBU_DEF_H */
